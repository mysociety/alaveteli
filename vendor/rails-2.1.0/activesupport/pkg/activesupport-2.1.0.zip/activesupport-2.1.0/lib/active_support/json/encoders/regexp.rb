class Regexp
  def to_json(options = nil) #:nodoc:
    inspect
  end
end
