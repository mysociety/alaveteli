class Ship < ActiveRecord::Base
  self.record_timestamps = false
end