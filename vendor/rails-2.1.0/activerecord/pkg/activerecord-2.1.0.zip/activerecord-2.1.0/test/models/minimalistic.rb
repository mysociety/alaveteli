class Minimalistic < ActiveRecord::Base
end
